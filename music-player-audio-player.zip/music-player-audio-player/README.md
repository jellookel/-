# Music Player | Audio Player 🎵

A Pen created on CodePen.

Original URL: [https://codepen.io/jellokell/pen/ogNLWry](https://codepen.io/jellokell/pen/ogNLWry).

Simple Beautiful Fully Functional Music | Audio Player.

Design inspired by: https://dribbble.com/shots/4240318-Made-with-InVision-Studio-Music-Player